select * from tbSysInfo

