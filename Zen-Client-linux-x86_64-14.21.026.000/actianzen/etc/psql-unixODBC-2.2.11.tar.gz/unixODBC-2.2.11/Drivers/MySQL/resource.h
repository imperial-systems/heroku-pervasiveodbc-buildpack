//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by myodbc3.rc
//
#define DRIVERCONNECT                   104
#define IDD_HELP                        105
#define IDB_BITMAP1                     111
#define IDI_ICON1                       112
#define MYHELP                          112
#define IDBITMAP                        116
#define HELPDIALOG                      119
#define IDB_BITMAP2                     137
#define BMP_MYSQL                       158
#define IDC_DSNAME                      400
#define IDC_DSNAMETEXT                  401
#define IDC_SERVER                      402
#define IDC_PASSWORDTEXT                403
#define IDC_DESC                        404
#define IDC_USER                        405
#define IDC_USERTEXT                    406
#define IDC_PASSWORD                    407
#define IDC_SERVERTEXT                  408
#define IDC_DESCRIPTION                 409
#define IDS_MSGTITLE                    500
#define IDS_BADDSN                      501
#define IDC_PORT                        1000
#define IDC_STMT                        1001
#define IDC_DB                          1005
#define IDC_FLAGTEXT                    1007
#define IDC_FLAG                        1009
#define IDC_PORTTEXT                    1010
#define IDC_RADIO1                      1011
#define IDC_RADIO2                      1012
#define IDC_RADIO3                      1013
#define IDC_RADIO7                      1014
#define IDC_RADIO5                      1015
#define IDC_RADIO6                      1016
#define IDC_RADIO4                      1017
#define IDC_RADIO8                      1018
#define IDC_RADIO9                      1019
#define IDC_RADIO10                     1020
#define IDC_RADIO11                     1021
#define IDC_RADIO12                     1022
#define IDC_RADIO13                     1023
#define IDC_CHECK1                      1024
#define IDC_CHECK2                      1025
#define IDC_CHECK3                      1026
#define IDC_CHECK4                      1027
#define IDC_CHECK5                      1028
#define IDC_CHECK6                      1029
#define IDC_CHECK7                      1030
#define IDC_CHECK8                      1031
#define IDC_CHECK9                      1032
#define IDC_CHECK10                     1033
#define IDC_CHECK11                     1034
#define IDC_CHECK12                     1035
#define IDC_CHECK13                     1036
#define IDC_CHECK14                     1037
#define IDC_CHECK15                     1038
#define IDC_CHECK16                     1039
#define IDC_CHECK17                     1040
#define IDC_CHECK18                     1041
#define IDC_CHECK19                     1042
#define IDC_ERROR                       1045
#define IDTEST                          1063
#define IDHSTATIC                       1067
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        163
#define _APS_NEXT_COMMAND_VALUE         40013
#define _APS_NEXT_CONTROL_VALUE         1090
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
